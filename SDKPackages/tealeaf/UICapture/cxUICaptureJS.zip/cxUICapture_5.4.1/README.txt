UI Capture SDK release package contents

jQuery
  Folder containing the production build for the jQuery flavor of the UIC.
  Files include the base SDK, gestures module, JS for including in the cross-domain
  frame based solution and minified copies of the same.

W3C
  Folder containing the production build for the W3C flavor of the UIC.
  Files include the base SDK, gestures module, JS for including in cross-domain
  frame based solution and minified copies of the same.

  This is the recommended flavor suitable for integration with all types of
  web applications irrespective of if they are incorporating jQuery or not.

Targets
  Folder containing sample implementations of Tealeaf Target files for various
  server application platforms like ASPX, JSP and PHP.

  The sample targets are only applicable for the on-prem solution.

defaultconfiguration.js
  Default configuration file which can be used as an example or starting point for
  either the W3C or the jQuery flavor. NOTE: The configuration, which also
  incorporates an API call to initialize the library, must be appended or included
  after the jQuery or W3C flavor of the UIC.


Release Notes and related documentation is available online:
https://developer.ibm.com/customer-engagement/docs/watson-marketing/ibm-watson-customer-experience-analytics/tealeaf-ui-capture/ibm-tealeaf-ui-capture-release-notes/
