
/*!
 * Copyright (c) 2026 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 *
 * @version 6.4.207
 * @flags NDEBUG
 */

/**
 * @fileOverview The Ajax Listener module implements the functionality related to
 * listening and logging XHR requests and responses.
 * @exports ajaxListener
 */

/*global TLT:true */
/* jshint loopfunc:true */

TLT.addModule("ajaxListener", function (context) {
    "use strict";

    let moduleConfig = {},
        moduleLoaded = false,
        nativeXHROpen,
        nativeFetch,
        xhrEnabled,
        fetchEnabled,
        performanceObserver,
        hookHealthInterval,
        xhrHookActive = false,
        fetchHookActive = false;
    const utils = context.utils;

    /**
     * Apply privacy to the message before it is added to the queue
     * @param {Object} msg The type 5 message object
     * @returns {Object} The type 5 message object with privacy applied
     */
    function maskData(msg) {
        const msgData = msg.customEvent.data,
            blockNonJSONResponse = moduleConfig.blockNonJSONResponse || false,
            fieldBlocklist = moduleConfig.fieldBlocklist || [];
        let cType;

        function masker(key, value) {
            return fieldBlocklist.some((item) => item === key || (item.cRegex && item.cRegex.test(key))) ? "XXXXX" : value;
        }

        function maskValues(data) {
            try {
                const dataStr = JSON.stringify(data, masker);
                return JSON.parse(dataStr);
            } catch (e) {
                if (moduleConfig.debugLog) {
                    console.warn("[ajaxListener] Error applying Ajax Listener privacy:", e.message);
                }
                return `Error applying Ajax Listener privacy - ${e.message}`;
            }
        }

        if (msgData.length !== 0) {
            if (blockNonJSONResponse) {
                cType = msgData.responseHeaders && msgData.responseHeaders["content-type"];
                if (!cType || cType.indexOf("application/json") === -1) {
                    msgData.response = "non-JSON data has been masked";
                }
            }
            msg.customEvent.data = maskValues(msgData);
        }
        return msg;
    }

    /**
     * Convert a relative or absolute URL to a full absolute URL with protocol and host.
     * The anchor element's href property automatically resolves URLs correctly:
     * - Relative URLs ("/api/data") are resolved against the current page's origin
     * - Absolute URLs ("https://api.other.com/data") are preserved with their own domain
     * @param {String} url The URL to convert (can be relative or absolute, same-domain or cross-domain)
     * @returns {String} The full absolute URL including protocol and host
     */
    function getFullUrl(url) {
        const dummyLink = document.createElement("a");
        dummyLink.href = url;
        return dummyLink.href;
    }

    /**
     * Extract query string parameters from a URL and return as an object.
     * @param {String} url The URL to extract query parameters from
     * @returns {Object} An object containing key-value pairs of query parameters. Returns empty object if no parameters exist.
     */
    function extractQueryParams(url) {
        const queryParams = {};
        try {
            const dummyLink = document.createElement("a");
            dummyLink.href = url;
            const searchString = dummyLink.search;

            if (searchString && searchString.length > 1) {
                // Remove the leading '?' and split by '&'
                const pairs = searchString.substring(1).split("&");
                pairs.forEach((pair) => {
                    const [key, value] = pair.split("=");
                    if (key) {
                        // Decode URI components and handle missing values
                        queryParams[decodeURIComponent(key)] = value ? decodeURIComponent(value) : "";
                    }
                });
            }
        } catch (e) {
            if (moduleConfig.debugLog) {
                console.warn("[ajaxListener] Error extracting query parameters:", e.message);
            }
        }
        return queryParams;
    }

    /**
     * Test if the given url matches an entry in the URL blocklist.
     * @param {String} url The value to be matched
     * @returns {Boolean} true if the url matches an entry in the URL blocklist. false otherwise.
     */
    function isUrlBlocked(url) {
        const urlBlocklist = moduleConfig.urlBlocklist;
        return !!(urlBlocklist && urlBlocklist.some((rule) => rule.cRegex.test(url)));
    }

    /**
     * Search the list of filters and return the 1st filter that completely
     * matches the XHR object. Filter properties include url, method and status.
     * @param {String} url The full request URL including protocol and host
     * @param {String} method The request method, e.g. post, get, etc
     * @param {String} status The response status
     * @returns {Object} An empty object if no filters have been configured. Else
     * returns the matching filter object or null if no object matches.
     */
    function getMatchingFilter(url, method, status) {
        const filters = moduleConfig.filters;

        if (!filters || !filters.length) {
            return {};
        }

        const result = filters.find((filter) => {
            const urlMatch = !filter.url || filter.url.cRegex.test(url);
            const methodMatch = !filter.method || filter.method.cRegex.test(method);
            const statusMatch = !filter.status || filter.status.cRegex.test(status);
            return urlMatch && methodMatch && statusMatch;
        });
        return result !== undefined ? result : null;
    }

    /**
     * Builds an object of key => value pairs of HTTP headers from a string.
     * @param {String} headers The string of HTTP headers separated by newlines
     *      (i.e.: "Content-Type: text/html\nLast-Modified: ..")
     * @return {Object} Returns an object where every key is a header
     *     and every value it's corresponding value.
     */
    function extractResponseHeaders(headers) {
        return headers.split(/[\r\n]+/).reduce((obj, line) => {
            const [name, ...valueParts] = line.split(": ");
            const value = utils.rtrim(valueParts.join(": "));
            if (name && name.length) {
                obj[name] = value;
            }
            return obj;
        }, {});
    }

    /**
     * Posts the XHR object to the queue. The URL, method, status and time
     * fields are mandatory. The request/response headers and body are
     * added as per the options specified.
     * @param {XMLHttpRequest} xhr The XMLHttpRequest object to be recorded.
     * @param {Object} logOptions An object specifying if the request and
     *                 response headers and data should be recorded.
     */
    function logXHR(xhr, logOptions) {
        if (!xhr) return;

        const msg = {
                type: 5,
                customEvent: {
                    name: "ajaxListener",
                    data: { interfaceType: "XHR" }
                }
            },
            xhrMsg = msg.customEvent.data,
            dummyLink = document.createElement("a");
        let respText;

        dummyLink.href = xhr.tListener.url;
        xhrMsg.originalURL = dummyLink.host + (dummyLink.pathname[0] === "/" ? "" : "/") + dummyLink.pathname;
        xhrMsg.requestURL = context.normalizeUrl ? context.normalizeUrl(xhrMsg.originalURL, 3) : xhrMsg.originalURL;
        xhrMsg.queryParams = extractQueryParams(xhr.tListener.url);
        xhrMsg.description = `Full Ajax Monitor ${xhrMsg.requestURL}`;
        xhrMsg.method = xhr.tListener.method;
        xhrMsg.status = xhr.status;
        xhrMsg.statusText = xhr.statusText || "";
        xhrMsg.async = xhr.tListener.async;
        xhrMsg.ajaxResponseTime = xhr.tListener.end - xhr.tListener.start;
        xhrMsg.locationHref = context.normalizeUrl(document.location.href, 3);

        if (logOptions.requestHeaders) {
            xhrMsg.requestHeaders = xhr.tListener.reqHeaders;
        }
        if (logOptions.requestData && typeof xhr.tListener.reqData === "string" && !xhr.tListener.isSystemXHR) {
            try {
                xhrMsg.request = JSON.parse(xhr.tListener.reqData);
            } catch (e1) {
                xhrMsg.request = xhr.tListener.reqData;
            }
        }
        if (logOptions.responseHeaders) {
            xhrMsg.responseHeaders = extractResponseHeaders(xhr.getAllResponseHeaders());
        }
        if (logOptions.responseData) {
            if (typeof xhr.responseType === "undefined") {
                respText = xhr.responseText;
            } else if (xhr.responseType === "" || xhr.responseType === "text") {
                respText = xhr.response;
            } else if (xhr.responseType === "json") {
                xhrMsg.response = xhr.response;
            } else {
                xhrMsg.response = typeof xhr.response;
            }

            if (respText) {
                try {
                    xhrMsg.response = JSON.parse(respText);
                } catch (e2) {
                    xhrMsg.response = respText;
                }
            }

            if (xhr.responseType) {
                xhrMsg.responseType = xhr.responseType;
            }
        }
        context.post(maskData(msg));
    }

    function getEntries(object) {
        const obj = {};
        for (const [key, value] of object.entries()) {
            obj[key] = value;
        }
        return obj;
    }

    /**
     * Extract key => value pairs from fecth request/response headers.
     * @param {Object} headers fecth request/response headers
     * @return {Object} Returns an object where every key is a header
     *     and every value it's corresponding value.
     */
    function extractFetchHeaders(headers) {
        return getEntries(headers);
    }

    /**
     * Extract body of request based on types
     * supported types are string, json object, FormData object.
     * the rest types are returned as it is.
     * @param {Object} body fetch request body
     * @return {Object} Return a string, or an object
     */
    function extractFetchRequestBody(body) {
        if (!body) {
            return body;
        }

        if (typeof body === "object" && body.toString().indexOf("FormData") !== -1) {
            return getEntries(body);
        }

        if (typeof body === "string") {
            try {
                return JSON.parse(body);
            } catch (e) {
                return body;
            }
        }

        return body;
    }

    /**
     * Posts the fetch request/response information to the queue. The URL, method, status and time
     * fields are mandatory. The request/response headers and body are
     * added as per the options specified.
     * @param {Object} fetchReq The fetch request object to be recorded.
     * @param {Object} fetchResp The fetch response object to be recorded.
     * @param {Object} logOptions An object specifying if the request and
     *                 response headers and data should be recorded.
     */
    function logFetch(fetchReq, fetchResp, logOptions) {
        const msg = {
                type: 5,
                customEvent: {
                    name: "ajaxListener",
                    data: { interfaceType: "fetch" }
                }
            },
            xhrMsg = msg.customEvent.data,
            dummyLink = document.createElement("a");

        dummyLink.href = fetchReq.url;
        xhrMsg.originalURL = dummyLink.host + (dummyLink.pathname[0] === "/" ? "" : "/") + dummyLink.pathname;
        xhrMsg.requestURL = context.normalizeUrl ? context.normalizeUrl(xhrMsg.originalURL, 3) : xhrMsg.originalURL;
        xhrMsg.queryParams = extractQueryParams(fetchReq.url);
        xhrMsg.description = `Full Ajax Monitor ${xhrMsg.requestURL}`;
        xhrMsg.method = fetchReq.initData.method;
        xhrMsg.status = fetchResp.status;
        xhrMsg.statusText = fetchResp.statusText || "";
        xhrMsg.async = true;
        xhrMsg.ajaxResponseTime = fetchReq.end - fetchReq.start;
        xhrMsg.responseType = fetchResp.type;
        xhrMsg.locationHref = context.normalizeUrl(document.location.href, 3);

        if (logOptions.requestHeaders) {
            // Check if header data is encapsulated as "Headers" object which cannot be directly accessed
            if (fetchReq.initData.headers && fetchReq.initData.headers.toString().indexOf("Headers") !== -1) {
                xhrMsg.requestHeaders = extractFetchHeaders(fetchReq.initData.headers);
            } else {
                xhrMsg.requestHeaders = fetchReq.initData.headers || "";
            }
        }

        if (logOptions.requestData && typeof fetchReq.body !== "undefined" && !fetchReq.isSystemXHR) {
            xhrMsg.request = extractFetchRequestBody(fetchReq.body);
        }

        if (logOptions.responseHeaders) {
            xhrMsg.responseHeaders = extractFetchHeaders(fetchResp.headers);
        }

        if (logOptions.responseData) {
            const respContentType = fetchResp.headers.get("content-type");

            if (respContentType && respContentType.indexOf("application/json") !== -1) {
                fetchResp.clone().json().then((responseData) => {
                    xhrMsg.response = responseData;
                    context.post(maskData(msg));
                }).catch((jsonError) => {
                    xhrMsg.response = {};
                    xhrMsg.responseError = `JSON parse error: ${jsonError.message !== undefined ? jsonError.message : "Invalid or empty JSON"}`;
                    if (moduleConfig.debugLog) {
                        console.warn("[ajaxListener] Invalid JSON in response");
                    }
                    context.post(maskData(msg));
                });
                return;
            }

            if (respContentType && (respContentType.indexOf("text") !== -1 || respContentType.indexOf("xml") !== -1)) {
                fetchResp.clone().text().then(function (responseData) {
                    xhrMsg.response = responseData;
                    context.post(maskData(msg));
                });
                return;
            }

            xhrMsg.response = `Not logging unsupported response content: ${respContentType}`;
        }
        context.post(maskData(msg));
    }

    /**
     * Process the XHR object to check if it matches with a filter
     * and if so then log it.
     * @param xhr {XMLHttpRequest} The XMLHttpRequest object to be processed.
     */
    function processXHR(xhr) {
        const url = getFullUrl(xhr.tListener.url),
            method = xhr.tListener.method,
            status = xhr.status.toString();
        let logOptions = {
            requestHeaders: false,
            requestData: false,
            responseHeaders: false,
            responseData: false
        };

        const filter = getMatchingFilter(url, method, status);
        if (filter) {
            if (filter.log) {
                logOptions = filter.log;
            }
            logXHR(xhr, logOptions);
        }
    }

    /**
     * Process the fetch request & response to check if it matches with a filter
     * and if so then log it.
     * @param fetchReq {Request} The request object of fetch
     * @param fetchResp {Response} The response object of fetch
     */
    function processFetch(fetchReq, fetchResp) {
        const url = getFullUrl(fetchReq.url),
            method = fetchReq.initData.method,
            status = fetchResp.status.toString();
        let logOptions = {
            requestHeaders: false,
            requestData: false,
            responseHeaders: false,
            responseData: false
        };

        if (isUrlBlocked(url)) return;

        const filter = getMatchingFilter(url, method, status);
        if (filter) {
            if (filter.log) {
                logOptions = filter.log;
            }
            logFetch(fetchReq, fetchResp, logOptions);
        }
    }

    /**
     * XHR readystatechange event handler. Checks if the readyState is "complete"
     * and processes the XHR for logging.
     * @param event {DOMEvent} Event object corresponding to the XHR readystatechange event.
     */
    function readyStateChangeHandler(event) {
        if (!event || !event.target) return;

        const xhr = event.target;

        if (xhr.readyState === 4) {
            xhr.removeEventListener("readystatechange", readyStateChangeHandler);
            xhr.tListener.end = Date.now();

            // Log error details when debugLog is enabled
            if (moduleConfig.debugLog && xhr.status >= 400) {
                console.group("[ajaxListener] XHR Error Context");
                console.log("URL:", xhr.tListener.url);
                console.log("Method:", xhr.tListener.method);
                console.log("Status:", xhr.status, xhr.statusText);
                console.log("Response Type:", xhr.responseType || "text");
                if (xhr.tListener.initiatorStack) {
                    console.log("Initiated from:", xhr.tListener.initiatorStack);
                }
                try {
                    const responseText = xhr.responseText || xhr.response;
                    if (responseText && typeof responseText === "string" && responseText.length < 500) {
                        console.log("Response:", responseText);
                    }
                } catch (e) {
                    // Ignore errors accessing response
                }
                console.groupEnd();
            }

            processXHR(xhr);
        }
    }

    /**
     * Creates a proxy function for the XMLHttpRequest.setRequestHeader method.
     * The proxy function records the header being set and invokes the original
     * method.
     * @param {XMLHttpRequest} xhr The XMLHttpRequest object.
     */
    function hookSetRequestHeader(xhr) {
        const savedSetRequestHeader = xhr.setRequestHeader;

        xhr.setRequestHeader = function (header, value) {
            const _xhr = this;
            const tListener = _xhr.tListener;

            if (header && header.length) {
                tListener.reqHeaders[header] = value;
            }
            return savedSetRequestHeader.apply(_xhr, arguments);
        };
    }

    /**
     * Creates a proxy function for the XMLHttpRequest.send method.
     * The proxy function records the request data being sent and
     * invokes the original method.
     * @param {XMLHttpRequest} xhr The XMLHttpRequest object.
     */
    function hookSend(xhr) {
        const savedSend = xhr.send;

        xhr.send = function (data) {
            const _xhr = this;
            const tListener = _xhr.tListener;

            if (data) {
                // TODO: Add additional checks to ensure data is serializable.
                tListener.reqData = data;
            }
            tListener.start = Date.now();

            // Add error event listener for network errors
            if (moduleConfig.debugLog) {
                _xhr.addEventListener("error", function (event) {
                    console.group("[ajaxListener] XHR Network Error Context");
                    console.log("URL:", _xhr.tListener.url);
                    console.log("Method:", _xhr.tListener.method);
                    console.log("Error Event:", event);
                    if (_xhr.tListener.initiatorStack) {
                        console.log("Initiated from:", _xhr.tListener.initiatorStack);
                    }
                    console.groupEnd();
                });

                _xhr.addEventListener("abort", function (event) {
                    console.group("[ajaxListener] XHR Aborted Context");
                    console.log("URL:", _xhr.tListener.url);
                    console.log("Method:", _xhr.tListener.method);
                    if (_xhr.tListener.initiatorStack) {
                        console.log("Initiated from:", _xhr.tListener.initiatorStack);
                    }
                    console.groupEnd();
                });

                _xhr.addEventListener("timeout", function (event) {
                    console.group("[ajaxListener] XHR Timeout Context");
                    console.log("URL:", _xhr.tListener.url);
                    console.log("Method:", _xhr.tListener.method);
                    console.log("Timeout:", _xhr.timeout);
                    if (_xhr.tListener.initiatorStack) {
                        console.log("Initiated from:", _xhr.tListener.initiatorStack);
                    }
                    console.groupEnd();
                });
            }

            return savedSend.apply(_xhr, arguments);
        };
    }

    /**
     * Check if the url matches tealeaf end point collector.
     * @param {String} url
     */
    function isSystemXHR(url) {
        const queueServiceConfig = TLT.getServiceConfig("queue");
        const queues = queueServiceConfig.queues || [];

        for (const queue of queues) {
            if (queue.endpoint && url.indexOf(queue.endpoint) !== -1) {
                return true;
            }
        }
        return false;
    }

    /**
     * Proxy function for XMLHttpRequest.prototype.open
     * Attaches the readystatechange handler and hook functions
     * for the XMLHttpRequest.setRequestHeader and
     * XMLHttpRequest.send methods.
     * @param {String} method
     * @param {String} url
     */
    function xhrOpenHook(method, url, async) {
        const xhr = this,
            fullUrl = getFullUrl(url);

        if (moduleLoaded && !isUrlBlocked(fullUrl)) {
            xhr.addEventListener("readystatechange", readyStateChangeHandler);

            xhr.tListener = {
                method: method,
                url: url,
                async: (typeof async === "undefined") ? true : !!async,
                reqHeaders: {},
                isSystemXHR: isSystemXHR(fullUrl)
            };

            // Capture stack trace for debugging when debugLog is enabled
            if (moduleConfig.debugLog) {
                try {
                    const stack = new Error().stack;
                    // Remove the first 2 lines (Error message and this hook function)
                    xhr.tListener.initiatorStack = stack.split("\n").slice(2).join("\n");
                } catch (e) {
                    // Ignore errors capturing stack
                }
            }

            hookSetRequestHeader(xhr);
            hookSend(xhr);
        }
        return nativeXHROpen.apply(xhr, arguments);
    }

    /**
     * Save the original XMLHttpRequest.prototype.open method and replace
     * it with a proxy function using cooperative chaining pattern.
     * This allows multiple monitoring tools to coexist.
     */
    function addXHRHook() {
        if (!XMLHttpRequest) {
            return;
        }

        const currentOpen = XMLHttpRequest.prototype.open;

        // Check if there's already a wrapper in place
        const hasExistingWrapper = currentOpen !== XMLHttpRequest.prototype.open.originalNative
            && currentOpen.toString().indexOf("[native code]") === -1;

        // Save the truly native or the existing wrapper
        nativeXHROpen = currentOpen;

        // Mark our hook so other tools can detect it
        xhrOpenHook.isTLTHook = true;
        xhrOpenHook.originalNative = hasExistingWrapper ? currentOpen : currentOpen;

        XMLHttpRequest.prototype.open = xhrOpenHook;
        xhrHookActive = true;

        if (hasExistingWrapper && moduleConfig.debugLog) {
            console.info("[ajaxListener] Cooperative chaining: XHR hook detected and preserved");
        }
    }

    /**
     * Override native fetch API using cooperative chaining pattern.
     * This allows multiple monitoring tools to coexist.
     */
    function addFetchHook() {
        if (!window.fetch) {
            return;
        }

        const currentFetch = window.fetch;

        // Check if there's already a wrapper in place
        const hasExistingWrapper = currentFetch.toString().indexOf("[native code]") === -1;

        // Save the truly native or the existing wrapper
        nativeFetch = currentFetch;

        const fetchHook = function (url, options) {
            const fetchReq = {};

            if (typeof url === "object") {
                // Check if it's a Request object (has clone method) vs URL object (has href property)
                if (url instanceof Request) {
                    // Handle Request object
                    fetchReq.initData = {
                        method: url.method,
                        headers: url.headers,
                        body: url.body,
                        mode: url.mode,
                        credentials: url.credentials,
                        cache: url.cache,
                        redirect: url.redirect,
                        referrer: url.referrer,
                        integrity: url.integrity
                    };
                    fetchReq.url = url.url;

                    // Clone and extract body from Request object
                    url.clone().text().then((data) => {
                        if (data.length > 0) {
                            fetchReq.body = data;
                        }
                    }).catch(() => {
                        // Ignore errors reading body (e.g., already consumed)
                    });
                } else if (url.href) {
                    // Handle URL object
                    fetchReq.url = url.href;
                    fetchReq.initData = options !== undefined ? options : {};
                    fetchReq.body = options && options.body;
                } else {
                    // Handle other object types (fallback)
                    fetchReq.url = url.toString();
                    fetchReq.initData = options !== undefined ? options : {};
                    fetchReq.body = options && options.body;
                }
            } else {
                // Handle string URL
                fetchReq.initData = options !== undefined ? options : {};
                fetchReq.url = url;
                fetchReq.body = options && options.body;
            }

            const fullUrl = getFullUrl(fetchReq.url);
            fetchReq.isSystemXHR = isSystemXHR(fullUrl);
            fetchReq.start = Date.now();

            // Capture stack trace for debugging when debugLog is enabled
            if (moduleConfig.debugLog) {
                try {
                    const stack = new Error().stack;
                    // Remove the first 2 lines (Error message and this hook function)
                    fetchReq.initiatorStack = stack.split("\n").slice(2).join("\n");
                } catch (e) {
                    // Ignore errors capturing stack
                }
            }

            const promise = nativeFetch.apply(this, arguments);

            return promise.then((response) => {
                fetchReq.end = Date.now();

                // Log error details when debugLog is enabled
                if (moduleConfig.debugLog && response.status >= 400) {
                    console.group("[ajaxListener] Fetch Error Context");
                    console.log("URL:", fetchReq.url);
                    console.log("Method:", fetchReq.initData.method || "GET");
                    console.log("Status:", response.status, response.statusText);
                    console.log("Response Type:", response.type);
                    if (fetchReq.initiatorStack) {
                        console.log("Initiated from:", fetchReq.initiatorStack);
                    }
                    console.groupEnd();
                }

                processFetch(fetchReq, response);
                return response;
            }).catch((error) => {
                // Log fetch network errors when debugLog is enabled
                if (moduleConfig.debugLog) {
                    console.group("[ajaxListener] Fetch Network Error Context");
                    console.log("URL:", fetchReq.url);
                    console.log("Method:", fetchReq.initData.method || "GET");
                    console.log("Error:", error.message);
                    console.log("Error Type:", error.name);
                    if (fetchReq.initiatorStack) {
                        console.log("Initiated from:", fetchReq.initiatorStack);
                    }
                    console.groupEnd();
                }
                // Re-throw the error to maintain original behavior
                throw error;
            });
        };

        // Mark our hook so other tools can detect it
        fetchHook.isTLTHook = true;
        fetchHook.originalNative = currentFetch;

        window.fetch = fetchHook;
        fetchHookActive = true;

        if (hasExistingWrapper && moduleConfig.debugLog) {
            console.info("[ajaxListener] Cooperative chaining: Fetch hook detected and preserved");
        }
    }

    /**
     * Process PerformanceResourceTiming entries to log AJAX calls.
     * Used as a non-invasive fallback when hooks fail or are disabled.
     * @param {PerformanceEntry[]} entries The performance entries to process
     */
    function processPerformanceEntries(entries) {
        entries.forEach((entry) => {
            if (entry.entryType !== "resource" || !entry.name) {
                return;
            }

            // Filter to only XMLHttpRequest and fetch entries
            if (entry.initiatorType !== "xmlhttprequest" && entry.initiatorType !== "fetch") {
                return;
            }

            const url = getFullUrl(entry.name);

            if (isUrlBlocked(url) || isSystemXHR(url)) {
                return;
            }

            // Extract method and status from the entry (limited info available)
            // PerformanceObserver doesn't provide method or status, so we use defaults
            const method = "GET"; // Default assumption
            const status = entry.responseStatus !== undefined ? entry.responseStatus.toString() : "200"; // May not be available

            const filter = getMatchingFilter(url, method, status);
            if (filter) {
                const msg = {
                    type: 5,
                    customEvent: {
                        name: "ajaxListener",
                        data: {
                            interfaceType: "PerformanceObserver",
                            originalURL: url,
                            requestURL: context.normalizeUrl ? context.normalizeUrl(url, 3) : url,
                            queryParams: extractQueryParams(entry.name),
                            description: `Full Ajax Monitor ${url}`,
                            method: method,
                            status: entry.responseStatus !== undefined ? entry.responseStatus : 0,
                            statusText: "",
                            async: true,
                            ajaxResponseTime: entry.duration,
                            locationHref: context.normalizeUrl(document.location.href, 3),
                        }
                    }
                };
                context.post(maskData(msg));
            }
        });
    }

    /**
     * Setup PerformanceObserver to monitor network requests as a fallback.
     * This provides non-invasive monitoring when hooks are disabled or fail.
     */
    function setupPerformanceObserver() {
        if (!window.PerformanceObserver) {
            return;
        }

        try {
            performanceObserver = new PerformanceObserver((list) => {
                processPerformanceEntries(list.getEntries());
            });

            performanceObserver.observe({ entryTypes: ["resource"] });

            if (moduleConfig.debugLog) {
                console.info("[ajaxListener] PerformanceObserver fallback enabled");
            }
        } catch (e) {
            if (moduleConfig.debugLog) {
                console.warn("[ajaxListener] Failed to setup PerformanceObserver:", e.message);
            }
        }
    }

    /**
     * Check if hooks are still active and working.
     * Warns if hooks have been overwritten by another tool.
     */
    function checkHookHealth() {
        let healthIssues = false;

        if (xhrEnabled && xhrHookActive) {
            const currentOpen = XMLHttpRequest.prototype.open;
            if (!currentOpen.isTLTHook) {
                if (moduleConfig.debugLog) {
                    console.warn("[ajaxListener] XHR hook has been overwritten by another tool");
                }
                xhrHookActive = false;
                healthIssues = true;
            }
        }

        if (fetchEnabled && fetchHookActive) {
            const currentFetch = window.fetch;
            if (!currentFetch.isTLTHook) {
                if (moduleConfig.debugLog) {
                    console.warn("[ajaxListener] Fetch hook has been overwritten by another tool");
                }
                fetchHookActive = false;
                healthIssues = true;
            }
        }

        if (healthIssues && !performanceObserver && moduleConfig.enablePerformanceObserverFallback !== false) {
            if (moduleConfig.debugLog) {
                console.info("[ajaxListener] Enabling PerformanceObserver fallback due to hook issues");
            }
            setupPerformanceObserver();
        }
    }

    /**
     * Start monitoring hook health at regular intervals.
     */
    function startHookHealthMonitoring() {
        const interval = moduleConfig.hookHealthCheckInterval !== undefined ? moduleConfig.hookHealthCheckInterval : 5000;
        if (moduleConfig.monitorHookHealth !== false && interval > 0) {
            hookHealthInterval = setInterval(checkHookHealth, interval);
        }
    }

    /**
     * Stop monitoring hook health.
     */
    function stopHookHealthMonitoring() {
        if (hookHealthInterval) {
            clearInterval(hookHealthInterval);
            hookHealthInterval = null;
        }
    }

    /**
     * Cleanup PerformanceObserver.
     */
    function cleanupPerformanceObserver() {
        if (performanceObserver) {
            performanceObserver.disconnect();
            performanceObserver = null;
        }
    }

    /**
     * Cache the regex specified in the module configuration.
     * @param {Object} obj The property with the regex to be cached.
     */
    function cacheRegex(obj) {
        if (obj && obj.regex) {
            obj.cRegex = new RegExp(obj.regex, obj.flags);
        }
    }

    /**
     * Process the module configuration and setup the corresponding cookies and tokens.
     * Setup the callback to add the respective headers when the library POSTs.
     * @function
     * @private
     * @param {object} config The module configuration.
     */
    function processConfig(config) {
        let cooperativeChaining = utils.getValue(config, "cooperativeChaining", false);
        if (config && config.skipSafetyCheck && config.cooperativeChaining === undefined) {
            cooperativeChaining = true;
        }
        const filters = config && config.filters !== undefined ? config.filters : [];

        for (let i = 0, len = filters.length; i < len; i += 1) {
            const filter = filters[i];
            utils.forEach([filter.url, filter.method, filter.status], cacheRegex);
        }

        if (config && config.urlBlocklist) {
            utils.forEach(config.urlBlocklist, cacheRegex);
        }
        if (config && config.fieldBlocklist) {
            utils.forEach(config.fieldBlocklist, cacheRegex);
        }

        xhrEnabled = utils.getValue(config, "xhrEnabled", true) && window.XMLHttpRequest;

        if (xhrEnabled && !cooperativeChaining
            && (XMLHttpRequest.toString().indexOf("[native code]") === -1
             || XMLHttpRequest.toString().indexOf("XMLHttpRequest") === -1)) {
            xhrEnabled = false;
        }

        fetchEnabled = utils.getValue(config, "fetchEnabled", true) && window.fetch;

        if (fetchEnabled && !cooperativeChaining
            && window.fetch.toString().indexOf("[native code]") === -1) {
            fetchEnabled = false;
        }
    }

    // Return the module's interface object. This contains callback functions which
    // will be invoked by the UIC core.
    return {
        init: function () {
            moduleConfig = context.getConfig();
            processConfig(moduleConfig);
        },

        destroy: function () {
            moduleLoaded = false;
            stopHookHealthMonitoring();
            cleanupPerformanceObserver();
        },

        onevent: function (webEvent) {
            switch (webEvent.type) {
            case "load":
                // Check if user prefers PerformanceObserver over hooks
                if (moduleConfig.preferPerformanceObserver) {
                    setupPerformanceObserver();
                } else {
                    if (xhrEnabled) {
                        addXHRHook();
                    }

                    if (fetchEnabled) {
                        addFetchHook();
                    }

                    // Start monitoring hook health if enabled
                    startHookHealthMonitoring();

                    // Setup PerformanceObserver as additional fallback if configured
                    if (moduleConfig.enablePerformanceObserverFallback) {
                        setupPerformanceObserver();
                    }
                }
                moduleLoaded = true;
                break;
            case "pagehide":
                moduleLoaded = false;
                stopHookHealthMonitoring();
                cleanupPerformanceObserver();
                break;
            default:
                break;
            }
        },

        version: "1.4.0"
    };

});
